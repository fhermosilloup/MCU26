/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/*
 * Paso 1. 	En Middlewares/ST/STM32_USB_Device_Library/Class/HID/Src/usbd_hid.c, buscar
 *			USBD_HID_CfgFSDesc para cambiar el tipo de Device a Keyboard
 * Paso 2. 	En Middlewares/ST/STM32_USB_Device_Library/Class/HID/Src/usbd_hid.c, buscar
 * 			HID_MOUSE_ReportDesc cambiando el report descriptor por el de keyboard
 * Paso 3.	En Middlewares/ST/STM32_USB_Device_Library/Class/HID/Src/usbd_hid.h, buscar
 * 			HID_MOUSE_REPORT_DESC_SIZE y cambialo por 63
 * Paso 3.	En Middlewares/ST/STM32_USB_Device_Library/Class/HID/Src/usbd_hid.h, buscar
 * 			HID_EPIN_SIZE y cambialo por 8
 */
#include "usbd_hid.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/**
 * @brief USB HID Keyboard Input Report (Boot Protocol - 8 bytes)
 *
 * Representa el estado instantáneo del teclado como un snapshot (no eventos).
 * El host interpreta las teclas presionadas comparando reportes consecutivos.
 *
 * Formato fijo definido por HID Boot Protocol:
 *   Byte 0: Modifiers (bitmap de 8 bits)
 *           bit 0: Left Ctrl
 *           bit 1: Left Shift
 *           bit 2: Left Alt
 *           bit 3: Left GUI
 *           bit 4: Right Ctrl
 *           bit 5: Right Shift
 *           bit 6: Right Alt
 *           bit 7: Right GUI
 *   Byte 1: Reservado (0x00)
 *   Byte 2-7: Hasta 6 keycodes simultáneos (6KRO)
 *
 * Notas de operación:
 *   - No incluye ASCII, solo keycodes HID
 *   - Layout y traducción los maneja el sistema operativo
 *   - Para liberar teclas: enviar todos los campos en 0
 *   - Para overflow (>6 teclas): usar ErrorRollOver (0x01 en keys[])
 *
 * Tamaño total: 8 bytes
 */
typedef struct
{
	uint8_t modifier;
	uint8_t reserved;
	uint8_t keys[6];
} hid_keyboard_report_t;


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern USBD_HandleTypeDef hUsbDeviceFS; // Imported from usb_device.c
hid_keyboard_report_t keyboard_report = {0,0,{0,0,0,0,0,0}};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void usb_kb_hid_send(char *keys){
	for(int i = 0; i < strlen(keys)+1; i++)
	{
		char charToType = keys[i];
		uint8_t keycode = 0x00;
		uint8_t modifier = 0x00;
		if(charToType >= 'A' && charToType <= 'Z')
		{
			modifier = 0x02;
			keycode = charToType-'A' + 0x04;
		}
		else if(charToType >= 'a' && charToType <= 'z')
		{
			keycode = charToType - 'a' + 0x04;
		}
		else
		{
			switch(charToType) {
				case '1': keycode = 0x1E; break;
				case '2': keycode = 0x1F; break;
				case '3': keycode = 0x20; break;
				case '4': keycode = 0x21; break;
				case '5': keycode = 0x22; break;
				case '6': keycode = 0x23; break;
				case '7': keycode = 0x24; break;
				case '8': keycode = 0x25; break;
				case '9': keycode = 0x26; break;
				case '0': keycode = 0x27; break;
				case '\n': keycode = 0x28; break;
				case '\b': keycode = 0x2A; break;
				case ' ': keycode = 0x2C; break;
				case '-': keycode = 0x2D; break;
				case ';': keycode = 0x33; break; // semi-colon
				case ':': keycode = 0x33; modifier=0x02; break; // colon
				case '\'': keycode = 0x34; break; // single quote
				case '\"': keycode = 0x34; modifier=0x02; break; // double quote
				case '/': keycode = 0x38; break; // slash
				case '.': keycode = 0x37; break; // slash
				default: keycode = 0x00; break; // Default case for undefined characters
			}
		}

		// Key pressed
		keyboard_report.modifier=modifier;
		keyboard_report.keys[0]=keycode;
		USBD_HID_SendReport(&hUsbDeviceFS, (uint8_t *)&keyboard_report, sizeof(hid_keyboard_report_t));
		HAL_Delay(25);

		// Key released
		keyboard_report.modifier=0x00;
		keyboard_report.keys[0]=0x00;
		USBD_HID_SendReport(&hUsbDeviceFS, (uint8_t *)&keyboard_report, sizeof(hid_keyboard_report_t));
		HAL_Delay(25);
	}
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  GPIOC->ODR |= (1 << 13);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  // Assign variables based on measurements
	  // e.g., from accelerometer, button, etc
	  usb_kb_hid_send("Hola Mundo\n");
	  HAL_Delay(1000);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
